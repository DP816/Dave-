// Joshua Ciffer 6/8/2017 //

public class Program21 {

	public static void main(String[] args) {

		int i = 300 ;
		while (i >= 3) {
			if ((i % 3) == 0) {
				System.out.println(i) ;
			}
			i-- ;
		}
		
	}

}