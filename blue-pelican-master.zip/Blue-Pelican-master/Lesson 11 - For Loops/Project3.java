// Joshua Ciffer 5/8/2017 //

public class Project3 {

	public static void main(String[] args) {

		for (int x = 7 ; x <= 187 ; x += 7) {
			System.out.println(x) ; 
		}
		
	}

}