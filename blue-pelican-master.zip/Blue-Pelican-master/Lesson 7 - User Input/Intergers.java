// Joshua Ciffer 3/28/2017 //

import java.util.Scanner ;

public class Intergers {

	public static void main(String[] args) {

		Scanner Input = new Scanner(System.in) ;
		System.out.print("Enter your integer here: ") ;
		int i =Input.nextInt() ;
		Input.close();
		System.out.println(3 * i) ;
		
	}

}