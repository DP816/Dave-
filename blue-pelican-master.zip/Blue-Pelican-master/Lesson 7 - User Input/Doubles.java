// Joshua Ciffer 3/28/2017 //

import java.util.Scanner ;

public class Doubles {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in) ;
		System.out.println("Enter your decimal number here: ") ;
		double d = input.nextDouble() ;
		System.out.println(3 * d) ;
		input.close() ;
		
	}

}