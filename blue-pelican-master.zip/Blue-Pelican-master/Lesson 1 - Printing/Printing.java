// Joshua Ciffer 2/2/2017 //

public class Printing {

	public static void main(String[] args) {

		//In-Line comment
		/*
		 * Multi-Line Comment
		 */
		System.out.println("Hello World!") ;
		System.out.print("Hello") ;
		System.out.println("Hello") ;
		System.out.print("Hello") ;
		
	}

}