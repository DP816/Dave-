// Joshua Ciffer 2/2/2017 //

public class Address {

	public static void main(String[] args) {
		
		System.out.println("____________________________") ;
		System.out.println("|                     #####|") ;
		System.out.println("|                     #####|") ;
		System.out.println("|                     #####|") ;
		System.out.println("|                          |") ;
		System.out.println("|       Johnny Doeman      |") ;
		System.out.println("|   123 Getta Place Ave.   |") ;
		System.out.println("|     Nunya, NJ 07858      |") ;
		System.out.println("|                          |") ;
		System.out.println("|__________________________|") ;
	
	}

}