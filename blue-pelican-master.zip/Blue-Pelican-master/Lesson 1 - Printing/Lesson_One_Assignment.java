// Joshua Ciffer 2/3/2017 //

public class Lesson_One_Assignment {

	public static void main(String[] args) {

		System.out.println("From: Bill Smith") ;
		System.out.println("Dell Computer, Bldg 13") ;
		System.out.println("Date: April 12, 2005") ;
		System.out.println("") ;
		System.out.println("To: Jack Jones") ;
		System.out.println("") ;
		System.out.println("Message: Help! I'm trapped inside a computer!") ;
		
	}

}