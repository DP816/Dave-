// Joshua Ciffer 2/3/2017 //

public class Initials {

	public static void main(String[] args) {

		System.out.println("JJJJJJJJJJJJJ     CCCCCCCC") ;
		System.out.println("      J          C        ") ;
		System.out.println("      J          C        ") ;
		System.out.println("      J          C        ") ;
		System.out.println("   J  J          C        ") ;
		System.out.println("    JJ            CCCCCCCC") ;
		
	}

}