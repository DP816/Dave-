// Joshua Ciffer 2/7/2017 //

public class Assignment_2 {

	public static void main(String[] args) {

		System.out.println("Tom Brady Career Stats") ;
		System.out.println("______________________")  ;
		String Position = "Quarter Back" ;
		String Team = "Patriots" ;
		int Games_Played = 237 ;
		int Completed_Passes = 5_244 ;
		int Passing_Touchdowns = 456 ;
		int Longest_Completed_Pass = 99 ;
		double Pass_Completion_Percent = 63.8 ;
		System.out.println("Position: " + Position) ;
		System.out.println("Team: " + Team) ;
		System.out.println("Games Played: " + Games_Played + " Games") ;
		System.out.println("Completed Passes: " + Completed_Passes + " Passes") ;
		System.out.println("Passing Touchdowns: " + Passing_Touchdowns) ;
		System.out.println("Longest Completed Pass: " + Longest_Completed_Pass + " Yards") ;
		System.out.println("Pass Completion Percentage: " + Pass_Completion_Percent + "%") ;
		
	}

}