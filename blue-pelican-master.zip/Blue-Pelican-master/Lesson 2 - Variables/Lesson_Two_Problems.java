// Joshua Ciffer 2/3/2017 //

public class Lesson_Two_Problems {

	public static void main(String[] args) {

		// Problem #5
		double p = 1.921E-16 ;
		System.out.println("Double: " + p) ;
		// Problem #6
		int i = 407 ;
		System.out.println("Integer: " + i) ;
		// Problem #7
		String My_Name = "Joshua" ;
		System.out.println("Name: " + My_Name) ;
		// Problem #8
		String count = "" ;
		System.out.println("Problem #8: " + count) ;
		// Problem #9
		double bankBalance = 136.06 ;
		System.out.println("Bank Balance: " + bankBalance) ;
		
	}

}