// Joshua Ciffer 2/3/2017 //

public class Variables_Hello_World {

	public static void main(String[] args) {

		String a = "Hello" ;
		String b = " World!" ;
		System.out.println(a) ;
		System.out.println(b) ;
		System.out.println(a+b) ;
		int numberOne = 5 ;
		int numberTwo = 7 ;
		System.out.println(numberOne + numberTwo) ;
		System.out.println(numberOne * numberTwo) ;
		double numberThree = .5 ;
		System.out.println(numberThree) ;
		System.out.println(numberOne + numberTwo + numberThree) ;
		
	}

}