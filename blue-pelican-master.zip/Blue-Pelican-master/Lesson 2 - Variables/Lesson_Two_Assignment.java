// Joshua Ciffer 2/3/2017 //

public class Lesson_Two_Assignment {

	public static void main(String[] args) {

		int age = 15 ;
		int height_feet = 7 ;
		int height_inches = 14 ;
		int weight = 942 ;
		int shoe_size = 43 ;
		double gpa = 7.42 ;
		
		System.out.println("Age: " + age + " Years") ;
		System.out.print("Height: " + height_feet + " Ft ") ; 
		System.out.println(height_inches + " In") ;
		System.out.println("Weight: " + weight + " Lbs") ;
		System.out.println("Shoe Size: " + shoe_size) ;
		System.out.println("GPA: " + gpa) ;
		
	}

}