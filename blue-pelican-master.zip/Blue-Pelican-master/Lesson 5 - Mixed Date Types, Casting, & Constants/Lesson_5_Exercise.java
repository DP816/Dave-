// Joshua Ciffer 2/10/2017 //

public class Lesson_5_Exercise {

	public static void main(String[] args) {

		// Problem #1
		final double E = 2.718 ;
		System.out.println("Problem #1: " + E) ;
		// Problem #2
		final int NUM_STUDENTS = 236 ;
		System.out.println("Problem #2 " + NUM_STUDENTS) ;
		// Problem #3
		final double Area ;
		Area = 203.49 ;
		System.out.println("Problem #3: " + Area) ;
		// Problem #4
		int cnt = 27 ; //*
		System.out.println(cnt) ;
		// Problem #5
		double d = 78.1 ;
		int fg = (int)d ;
		System.out.println("Problem #4: " + fg) ;
		// Problem #6
		//double f4 = 22 ;
		// Problem #7
		double j = (double)61/3 ;
		System.out.println("Problem #7: " + j) ;
		// Problem #8
		System.out.println("Problem #8: " + ((double)(90/9))) ;
		// Problem #9
		System.out.println("Problem #9: " + (4+6.0/4+5*3-3)) ;
		// Problem #10
		int p = 3 ;
		double d_1 = 10.3 ;
		int j_1 = (int)5.9 ;
		System.out.println("Problem #10: " + (p+p*d_1-3*j_1)) ;
		// Problem #11
		int p_1 = 3 ;
		double d_2 = 10.3 ;
		int j_2 = (int)5.9 ;
		System.out.println("Problem #11 " + (p_1+p_1*(int)d_2-3*j_2)) ;
		// Problems #12-#15
		int dividend = 12 ;
		int divisor = 4 ;
		int quotient = 0 ;
		int remainder = 0 ;
		int dividend2 = 13 ;
		int divisor2 = 3 ;
		int quotient2 = 0 ;
		int remainder2 = 0 ;
		quotient = dividend/divisor ;
		remainder = dividend%divisor ;
		quotient2 = dividend2/divisor2 ;
		remainder2 = dividend%divisor2 ;
		// Problem #12
		System.out.println("Problem #12: " + quotient) ;
		// Problem #13
		System.out.println("Problem #13: " + remainder) ;
		// Problem #14
		System.out.println("Problem #14: " + quotient2) ;
		// Problem #15
		System.out.println("Problem #15: " + remainder2) ;
		// Problem #16 *******
		double d_3 = .5 ;
		int i = 2 ;
		int j_3 = (int)d_3/i ; 
		System.out.println("Problem #16: " + j_3) ;
		// Problem #17
		//final String M = "ugg" ;
		// M = "wow" ; illegal
		// Problem #18
		int k = 7 ;
		k*=.5; 
		System.out.println("Problem #18: " + k) ;
			
	}

}