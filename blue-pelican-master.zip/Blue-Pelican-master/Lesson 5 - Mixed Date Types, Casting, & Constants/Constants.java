// Joshua Ciffer 2/10/2017 //

public class Constants {

	public static void main(String[] args) {
	    
		final double x = 3.14159 ;
		final int y = 7 ;
		//final String z = "hello" ;
		System.out.println(x + y) ;

	}

}