// Joshua Ciffer 3/24/2017 //

public class Lesson_5 {

	public static void main(String[] args) {

		// #1
		final double E = 2.718 ;
		System.out.println("#1: " + E) ;
		// #2
		final int NUM_STUDENTS = 236 ;
		System.out.println("#2: " + NUM_STUDENTS) ;
		// #3
		final double Area ;
		Area = 203.49 ;
		System.out.println("#3: " + Area) ;
		// #4
		int cnt = 27 ;
		System.out.println("#4: " + cnt) ;
		// #5
		double d = 78.1 ;
		int fg = (int)d ;
		System.out.println("#5: " + fg) ;
		// #6
		double f4 = 22 ;
		System.out.println("#6: " + f4) ;
		// #7
		double j = 61/3 + (int).05 ;
		System.out.println("#7: " + j) ;
		// #8
		System.out.println("#8: " + (double)(90/9)) ;
		// #9
		System.out.println("#9: " + (4 + 6.0/4 + 5 * 3 - 3));
		// #10
		int p = 3 ;
		double d1 = 10.3 ;
		int j1 = (int)5.9 ;
		System.out.println("#10: " + (p + p * d1 - 3 * j1)) ;
		// #12-15
		int dividend = 12, divisor = 4, quotient = 0, remainder = 0 ;
		int dividend2 = 13, divisor2 = 3, quotient2 = 0, remainder2 = 0 ;
		quotient = dividend/divisor ;
		remainder = dividend%divisor ;
		quotient2 = dividend2/divisor2 ;
		remainder2 = dividend2%divisor2 ;
		// #12
		System.out.println("#12: " + quotient) ;
		// #13
		System.out.println("#13: " + remainder) ;
		// #14
		System.out.println("#14: " + quotient2) ;
		// #15
		System.out.println("#15: " + remainder2) ;
		// #16
		double d2 = 7 ;
		int i = 3 ;
		int j2 = (int)d2/i ;
		System.out.println("#16: " + j2) ;
		// #17
		//final String M = "ugg" ;
		//M = "wow" ;
		// #18
		int k = 7 ;
		k*=.5 ;
		System.out.println("#18: " + k) ;
		
		// PROJECT
		d1 = 37.9 ;
		d2 = 1004.128 ;
		//int i1 = 12 ;
		//int i2 = 18 ;
		
	}

}