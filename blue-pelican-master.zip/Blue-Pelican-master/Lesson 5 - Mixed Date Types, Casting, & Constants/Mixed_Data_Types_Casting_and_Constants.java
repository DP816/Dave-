// Joshua Ciffer 2/8/2017 //

public class Mixed_Data_Types_Casting_and_Constants {

	public static void main(String[] args) {

		double d = 29.78 ;
		int i = (int)d ;
		System.out.println(i) ;
		
		int j = 105 ;
		double c = j ;
		System.out.println(c) ;
		
		int x = 4 ;
		double y = 3 ;
		System.out.println(x/y) ;
		
		int a = 5 ;
		int b = 4 ;
		
		int ab_i = a/b ;
		System.out.println(ab_i) ;
		
		double ab_d = (double)a/b ;
		System.out.println(ab_d) ;
		
	}

}