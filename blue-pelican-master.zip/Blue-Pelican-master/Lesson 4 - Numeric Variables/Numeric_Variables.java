// Joshua Ciffer 2/6/2017 //

public class Numeric_Variables {

	public static void main(String[] args) {

		int x = 3 ;
		double y = 7 ;
		double z = y + x ;
		System.out.println(z) ;
		
		//double a, 
		// d ;
		//double r = 54, t = 42 ;
		
		//Increments
		int num = 5 ;
		System.out.println(++num) ;
		
		//Decrements
		System.out.println(--num) ;
		
	}

}