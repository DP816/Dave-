// Joshua Ciffer 2/7/2017 //

public class Tester_Lesson_4_Projcect {

	public static void main(String[] args) {

		String Problem_1 = "79 + 3 * (4 + 82 - 68) - 7 + 19" ;
		String Problem_2 = "(179 + 21 + 10) / 7 + 181" ;
		String Problem_3 = "10,389 * 56 * 11 + 2,246" ;
		int Answer_1 = (79+3*(4+82-68)-7+19) ;
		int Answer_2 = ((179+21+10)/7+181) ;
		int Answer_3 = (10_389*56*11+2_246) ;
		System.out.println(Problem_1 + " = " + Answer_1) ;
		System.out.println(Problem_2 + " = " + Answer_2) ;
		System.out.println(Problem_3 + " = " + Answer_3) ;
		
		
	}

}