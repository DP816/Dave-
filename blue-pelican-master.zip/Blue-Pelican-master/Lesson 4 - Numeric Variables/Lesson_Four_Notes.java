// Joshua Ciffer 2/21/2017 //

public class Lesson_Four_Notes {

	public static void main(String[] args) {

		//Modulus
		System.out.println(27%4) ; //3
		System.out.println(7%1.5); //1.0 *Answer is given in double because numbers were given in decimals.
		
		//Increment X++ ++x Increases by 1
		int x = 5 ;
		System.out.println(x) ;
		System.out.println(x++) ;
		System.out.println(x) ;
		System.out.println(x++) ;
		System.out.println(x) ;
		int y = 3 ;
		System.out.println(y) ;
		System.out.println(++y) ;
		System.out.println(y) ;
		System.out.println(y++) ;
		System.out.println(y) ;
		
		//Decrement X-- --X Decreases by 1
		
		//Compound Operators
		int num = 10 ;
		num += 5 ; //Adds to the variable
		System.out.println(num);
		 
	}

}