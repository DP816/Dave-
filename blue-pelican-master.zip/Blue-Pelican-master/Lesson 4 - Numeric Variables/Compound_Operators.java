// Joshua Ciffer 2/8/2017 //

public class Compound_Operators {

	public static void main(String[] args) {
		
		int x = 5 ;
		System.out.println("x = " +x) ;
		
		x += 4 ;
		System.out.println("x += 4 " + x) ;
		
	}

}