// Joshua Ciffer //

public class Test {

	public static void main(String[] args) {
		
		int x = 3 ;
		int y = 5 ;
		double a = 2.5 ;
		System.out.println(x*a) ;
		System.out.println(y/a) ;
		System.out.println(x/y) ;
		System.out.println(x-y*a) ;
		System.out.println((x+x+y)*a) ;
		System.out.println(y%x*x+y) ;
		
	}

}