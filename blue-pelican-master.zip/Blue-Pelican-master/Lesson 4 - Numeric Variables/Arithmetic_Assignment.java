// Joshua Ciffer 2/21/2017 //

public class Arithmetic_Assignment {

	public static void main(String[] args) {

		String Problem1 = "79 + 3 * (4 + 82 - 68) - 7 + 19" ;
		String Problem2 = "(179 + 21 + 10) / 7 + 181" ;
		String Problem3 = "10389 * 56 * 11 + 2246" ;
		int Answer1 = 79 + 3 * (4 + 82 -68) - 7 + 19 ;
		int Answer2 = (179 + 21 + 10) / 7 + 181 ;
		int Answer3 = 10_389 * 56 * 11 + 2_246 ;
		System.out.println(Problem1 + " = " + Answer1) ;
		System.out.println(Problem2 + " = " + Answer2) ;
		System.out.println(Problem3 + " = " + Answer3) ;
		
	}

}