// Joshua Ciffer 6/12/2017 //

package misc ;

public class Recipe {

	public Recipe(String theName) {
		
	}
	
	public void setServings(int x) {
		
	}
	
	//public double getRetailCost() {
	//	int x = 13 ;
	//	double tempCost = pricePerCalorie(x) * calories + cost ;
	///	return tempCost ;
	//}
	
	//private double pricePerCalorie(int z) {
		
	//}
	
	public int calories ;
	public int carbs ;
	public int fat ;
//	private double cost ;
	public String name ;
	
}