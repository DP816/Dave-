// Joshua Ciffer 6/12/2017 //

package diameter ;

public class Diameter {

	public static void main(String[] args) {
		
		Circle cir1 = new Circle(35.5) ;
		System.out.println(cir1.diameter()) ;
		
	}

}