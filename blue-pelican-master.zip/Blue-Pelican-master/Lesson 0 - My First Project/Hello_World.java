// Joshua Ciffer //

public class Hello_World {

	public static void main(String[] args) {
	
		System.out.print("Hello World!") ;
		
	}

}