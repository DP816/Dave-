// Joshua Ciffer 2/6/2017 //

public class String_Operations_Hello_World {

	public static void main(String[] args) {

		String mm = "Hello" ;
		String nx = "World!" ;
		System.out.println(mm + " " + nx) ;
			
	}

}