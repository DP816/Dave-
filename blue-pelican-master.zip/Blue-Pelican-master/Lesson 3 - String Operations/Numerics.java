// Joshua Ciffer 2/6/2017 //

public class Numerics {

	public static void main(String[] args) {

		int x = 27 ;
		String y = "Hi" ;
		String x_y = x + " " + y ;
		System.out.println(x_y) ;
		
	}

}