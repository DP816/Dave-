// Joshua Ciffer 2/7/2017 //

public class String_Operations_Substrings {

	public static void main(String[] args) {

		String x = "Hello World !" ;
		String x_subs =x.substring(4) ;
		System.out.println("Prnit started at character 4: " + x_subs) ;
		
		String y = "Hello my name is bob" ;
		String y_Substring = y.substring(2, 5) ;
		System.out.println("Print started at charcter 2, ended at 5: " + y_Substring) ;
		
	}

}