// Joshua Ciffer 2/6/2017 //

public class Cases {

	public static void main(String[] args) {

		String x = "Joshua Ciffer" ;
		System.out.println(x.toLowerCase()) ;
		System.out.println(x.toUpperCase()) ;
		
	}

}