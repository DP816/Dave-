// Joshua Ciffer 2/14/2016 //

public class Lesson_3_Assignment {

	public static void main(String[] args) {

		String pq = "Eddie Haskel" ;
		int hm = pq.length() ;
		String ed = pq.substring(hm-4) ;
		System.out.println(ed) ;
		
		String x = "Herman Munster" ;
		String y = x.substring(5) ;
		System.out.println(y) ;
		
	}

}