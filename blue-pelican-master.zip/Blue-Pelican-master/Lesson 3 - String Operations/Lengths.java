// Joshua Ciffer 2/6/2017 //

public class Lengths {

	public static void main(String[] args) {

		String x = "Hello World!" ;
		int x_length = x.length() ;
		System.out.println(x_length) ;
		
	}

}