// Joshua Ciffer 2/6/2017 //

public class Escape_Sequences {

	public static void main(String[] args) {

		String x = "Hello \"World\"" ;
		System.out.println("Escape Quotes: " + x) ; 
		String y = "Hello \nWorld!" ;
		System.out.println("Line Break: " + y) ;
		String z = "C:\\Folder\\File.txt" ;
		System.out.println(z) ;
		
	}

}